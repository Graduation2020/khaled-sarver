package com.example.androidserver.Common;

import com.example.androidserver.Model.User;

public class Common {
    public static User CurrentUser;


    public static final String UPDATE="Update";
    public static final String DELETE="Delete";


    public static final int PICK_IMAGE_REQUEST=71;

}
