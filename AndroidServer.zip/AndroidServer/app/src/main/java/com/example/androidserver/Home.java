package com.example.androidserver;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.androidserver.Common.Common;
import com.example.androidserver.Interface.ItemClickListener;
import com.example.androidserver.Model.Category;
import com.example.androidserver.ViewHolder.MenuViewHolder;
import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

import info.hoang8f.widget.FButton;

import static android.app.Activity.RESULT_OK;

public class Home {


    //FireBase
    FirebaseDatabase database;
    DatabaseReference categories;
    FirebaseRecyclerAdapter<Category, MenuViewHolder>adapter;

    FirebaseStorage storage;
    StorageRefernce storageRefernce;


    //View
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;


    //Add new menu Layout
    MaterialEditText edtName;
    FButton btnUpload,btnSelect;

    Category newCategory;

    Uri saveUri;






    prodected void onCreate{

        //Init Firebase
        database=FirebaseDatabase.getInstance();
        categories=database.getReference( "Category" );
        storage=FirebaseStorage.getInstance();
        storageRefernce=storage.getRefernce();




        //initView
        recycler_menu=(RecyclerView)findViewById(R.id.recycler_menu)
        recycler_menu.setHasfixedSize(ture);
        layoutManager=new LinearLayoutManger(this);
        recycler_menu.setLinearLayoutManger(layoutManager);

        loadMenu();




    }

    public void showDialog(){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder( Home.this);
                alertDialog.setTitle( "Add New Categoury" );
                alertDialog.setMessage( "Please Fill Full inforamtion" );

        LayoutInflater inflater=this.getLayoutInflater();
        View add_menu_layout=inflater.inflate( R.layout.add_new_mneu_layout,null );

        edtName=add_menu_layout.findViewById( R.id.edtName );
        btnSelect=add_menu_layout.findViewById( R.id.btnSelect );
        btnUpload=add_menu_layout.findViewById( R.id.btnUpload );



        //Event for button
        btnSelect.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    chooseImage();                       //Let The user to get photo from the gallary and save the uri
            }
        } );


        btnUpload.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                uploadImage();
            }
        } );




        alertDialog.setView( add_menu_layout );
        alertDialog.setIcon( R.drawable.ic_shopping_cart_black_24dp);

        //set Button

        alertDialog.setPositiveButton( "yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                    dialogInterface.dismiss();
                    if (newCategoryw != null)
                    {
                        categories.push().setValue( newCategory );
                        Snackbar.make(this,"New Category"+newCategory.getName()+"was added",Snackbar.LENGHT_SHORT).show();
                    }
            }


        } );
        alertDialog.setPositiveButton( "No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialogInterface.dismiss();

            }
        } );
        alertDialog.show();

    }

    private void uploadImage() {
        if(saveUri != null)
        {
            final ProgressDialog mDialog= new ProgressDialog( this );
            mDialog.setMessage( "Uploading . . ." );
            mDialog.show();

            String imageName= UUID.randomUUID().toString();
            final StorageReference imageFolder = storageRefernce.child("images/"+imageName);

            imageFolder.putFile(saveUri).addOnSuccessListener((OnSuccessListener) (taskSnapshot)  {

                    mDialog.dismiss();
                    Toast.makeText( Home.this,"Uploaded !!! ",Toast.LENGTH_SHORT ).show();
                    imageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        public void onSuccess(Uri uri) {
                            newCategory=new Category(edtName.getText().toString(),uri.toString());

                        }
                    });

                });
            .addOnFailureListener( new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                mDialog.dismiss();
                Toast.makeText( Home.this ,""+e.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
            .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>(){
                public void OnProgress(UploadTask.TaskSnapshot taskSnapshot){
                    double progress = (100.0*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                    mDialog.setMessage( "Uploaded "+progress );
            }
        });

        }
        }



    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode ==Common.PICK_IMAGE_REQUEST && resultCode ==RESULT_OK && data != null && data.getData()!= null)
        {
            saveUri=data.getData();
            btnSelect.setText("Image Selected !");
        }
    }





    private void chooseImage() {
        Intent intent=new Intent();
        intent.setType( "image/*" );
        intent.setAction( Intent.ACTION_GET_CONTENT );
        startActivityForResult(Intent.createChooser( intent,"Select Picture" ),Common.PICK_IMAGE_REQUEST);

    }





    private void loadMenu() {
        adapter=new FirebaseRecyclerAdapter<Category, MenuViewHolder>(
                Category.class,
                R.layout.menu_item,
                MenuViewHolder.class,
                categories

        ){
                protected void popualteViewHolder(MenuViewHolder viewHolder,Category model,int postion)
                {
                    viewHolder.txMenuName.setText(model.getName());
                            Picasso.with(Home.this).load(model.getImage()).into(viewHolder.imageView);

                            viewHolder.setItemClickListener(new ItemClickListener() {
                                @Override
                                public void OnClick(View view, int postion, boolean isLongClick) {

                                    Intent foodList = new Intent( Home.this,Foodlist.class );
                                    foodList.putExtra( "CategoryId",adapter.getRef().getKey() );
                                    startActivity(foodList);

                                }
                            }
                            );
                }
        };
    }


    public boolean onContextItemSelected(final MenuItem item) {

    if (item.getTitle().equals( Common.UPDATE )) {
        showUpdateDialog( adapter.getRef( item.getOrder() ).getKey(), adapter.getItem( item.getOrder() ) );
    } else if (item.getTitle().equals( Common.UPDATE )) {
        deleteCategory( adapter.getRef( item.getOrder() ).getKey() );
    }



        return super.onContextItemSelected(item);
    }

    private void showUpdateDialog( String key, Category item){

    AlertDialog.Builder alertDialog = new AlertDialog.Builder( Home.this);
    alertDialog.setTitle( "Updated Categoury" );
    alertDialog.setMessage( "Please Fill Full inforamtion" );

    LayoutInflater inflater=this.getLayoutInflater();
    View add_menu_layout=inflater.inflate( R.layout.add_new_mneu_layout,null );

    edtName=add_menu_layout.findViewById( R.id.edtName );
    btnSelect=add_menu_layout.findViewById( R.id.btnSelect );
    btnUpload=add_menu_layout.findViewById( R.id.btnUpload );


    edtName.setText(item.getName());



    //Event for button
    btnSelect.setOnClickListener( new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            chooseImage();             //Let The user to get photo from the gallary and save the uri
        }
    } );


    btnUpload.setOnClickListener( new View.OnClickListener() {
        @Override
        public void onClick(View v) {

          changeImage(item);

        }
    } );


    alertDialog.setView( add_menu_layout );
    alertDialog.setIcon( R.drawable.ic_shopping_cart_black_24dp);

    //set Button

    alertDialog.setPositiveButton( "yes", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            dialogInterface.dismiss();
            if (newCategoryw != null)
            {
                categories.push().setValue( newCategory );
                Snackbar.make(this,"New Category"+newCategory.getName()+"was added",Snackbar.LENGHT_SHORT).show();
            }
        }


    } );
    alertDialog.setPositiveButton( "No", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {

            dialogInterface.dismiss();

        }
    } );
    alertDialog.show();

}

    private void changeImage(final Category item) {

        if(saveUri != null)
        {
            final ProgressDialog mDialog= new ProgressDialog( this );
            mDialog.setMessage( "Uploading . . ." );
            mDialog.show();

            String imageName= UUID.randomUUID().toString();
            final StorageReference imageFolder = storageRefernce.child("images/"+imageName);

            imageFolder.putFile(saveUri).addOnSuccessListener((OnSuccessListener) (taskSnapshot) {

                    mDialog.dismiss();
            Toast.makeText( Home.this, "Uploaded !!! ", Toast.LENGTH_SHORT ).show();
            imageFolder.getDownloadUrl().addOnSuccessListener( new OnSuccessListener<Uri>() {
                public void onSuccess(Uri uri) {
                    public void onSuccess (Uri uri)
                    {
                        item.setImage( uri.toString() );

                    }
                }

            } );
            });
            .addOnFailureListener( new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                mDialog.dismiss();
                Toast.makeText( Home.this, "" + e.getMessage(), Toast.LENGTH_SHORT ).show();
            }
        } );
            .addOnProgressListener( new OnProgressListener<UploadTask.TaskSnapshot>() {
            public void OnProgress(UploadTask.TaskSnapshot taskSnapshot) {
                double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                mDialog.setMessage( "Uploaded " + progress );
            }
        } );

        }
    }

    private void deleteCategory(String key){
        categories.child( key ).removeValue();
        Toast.makeText( this,"Item Deleted !!!! ",Toast.LENGTH_SHORT ).show();
    }


}


