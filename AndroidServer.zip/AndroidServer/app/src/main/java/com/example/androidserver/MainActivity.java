package com.example.androidserver;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    Button SignInBt;
    TextView slogantx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );


        SignInBt= (Button)findViewById( R.id.SignInBt );
        slogantx=(TextView)findViewById( R.id.slogantx );

        Typeface face = Typeface.createFromAsset(getAssets(),"Fonts/NAbila.ttf");  ////Fonts Not Created
        slogantx.setTypeface(face);


        SignInBt.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signIn=new Intent( MainActivity.this,SignIn.class );
                startActivity( signIn );
            }
        } );





    }

}
