package com.example.androidserver.ViewHolder;

import android.view.ContextMenu;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.recyclerview.widget.RecyclerView;

import com.example.androidserver.Common.Common;
import com.example.androidserver.Interface.ItemClickListener;
import com.example.androidserver.R;

public abstract class MenuViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnCreateContextMenuListener {
    public TextView txMenuName;
    public ImageView imageView;


    private ItemClickListener itemClickListener;

    public MenuViewHolder(View itemView) {
        super(itemView);

        txMenuName=(TextView)itemView.findViewById( R.id.menu_name );
        imageView=(ImageView)itemView.findViewById( R.id.menu_image );

        itemView.setOnClickListener( this );
        itemView.setOnCreateContextMenuListener( this );




    }

    @Override
    public void onClick(View view) {
        itemClickListener.OnClick( view,getAdapterPosition(),false );

    }

    @Override
    public void onCreateContextMenu(ContextMenu contexMenu, View view, ContextMenu.ContextMenuInfo contexMenuInfo) {
        contexMenu.setHeaderTitle( "Select the action " );
        contexMenu.add(0,0,getAdapterPosition(), Common.UPDATE);
        contexMenu.add(0,1,getAdapterPosition(), Common.DELETE);
    }
}
