package com.example.androidserver.Interface;

import android.view.View;

public interface ItemClickListener {
    void OnClick(View view,int postion,boolean isLongClick);



}
