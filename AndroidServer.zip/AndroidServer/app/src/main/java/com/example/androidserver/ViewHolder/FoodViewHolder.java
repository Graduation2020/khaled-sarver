package com.example.androidserver.ViewHolder;

import android.view.ContextMenu;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.recyclerview.widget.RecyclerView;

import com.example.androidserver.Common.Common;
import com.example.androidserver.Interface.ItemClickListener;
import com.example.androidserver.R;

public abstract class FoodViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnCreateContextMenuListener {
    public TextView food_name;
    public ImageView food_image;


    private ItemClickListener itemClickListener;

    public FoodViewHolder(View itemView) {
        super(itemView);

        food_name=(TextView)itemView.findViewById( R.id.food_name );
        food_image=(ImageView)itemView.findViewById( R.id.food_image );

        itemView.setOnClickListener( this );
        itemView.setOnCreateContextMenuListener( this );

    }

    @Override
    public void onClick(View view) {
        itemClickListener.OnClick( view,getAdapterPosition(),false );

    }

    @Override
    public void onCreateContextMenu(ContextMenu contexMenu, View view, ContextMenu.ContextMenuInfo contexMenuInfo) {
        contexMenu.setHeaderTitle( "Select the action " );
        contexMenu.add(0,0,getAdapterPosition(), Common.UPDATE);
        contexMenu.add(0,1,getAdapterPosition(), Common.DELETE);
    }
}
