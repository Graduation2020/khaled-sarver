package com.example.androidserver;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.androidserver.Common.Common;
import com.example.androidserver.Interface.ItemClickListener;
import com.example.androidserver.Model.Category;
import com.example.androidserver.ViewHolder.FoodViewHolder;
import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

import info.hoang8f.widget.FButton;

import static android.app.Activity.RESULT_OK;

public class Foodlist {

    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;


    RelativeLayout rootLayout;

    FloatingaAtionButton fab;

    //FireBase

    FirebaseDatabase db;
    DatabaseReference foodList;
    FirebaseStorage storage;
    StorageReference storageReference;

    String categoryId="";

    FirebaseRecyclerAdapter<Food, FoodViewHolder>adapter;


    //add new food
    MaterialEditText edtName,edtDescription,edtPrice,edtDiscount;
    FButton btnSelect,btnUpload;

    Food newFood;

    Uri saveUri;



    protected void OnCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_list);

        db=FirebaseDatabase.getInstance(  );
        foodList=db.getReference("Foods");
        storage=FirebaseStorage.getInstance(  );
        storageReference=storage.getReference();


        recyclerView = (RecyclerView)findViewById(R.id.recycler_food);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager( this );
        recyclerView.setLayoutManager( layoutManager );



        rootLayout=(RelativeLayout)findViewById(R.id.rootLayout);



        fab=(FloatingActionbutton)findViewByid(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener(){
                public void OnClick(View view){
                    showAddFoodDialog();
                }

        } );

        if (getIntent != null)
        {
            categoryId=getIntent().getStringExtra("categoryId");
        }
        if (!categoryId.isEmpty())
            loadListFood(categoryId);

        


    }

    private void showAddFoodDialog() {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder( Home.this);
        alertDialog.setTitle( "Add New Food" );
        alertDialog.setMessage( "Please Fill Full inforamtion" );

        LayoutInflater inflater=this.getLayoutInflater();
        View add_menu_layout=inflater.inflate( R.layout.add_new_mneu_layout,null );

        edtName=add_menu_layout.findViewById( R.id.edtName );
        edtDescription=add_menu_layout.findViewById( R.id.edtDescription );
        edtPrice=add_menu_layout.findViewById( R.id.edtPrice );
        edtDiscount=add_menu_layout.findViewById( R.id.edtDiscount );


        btnSelect=add_menu_layout.findViewById( R.id.btnSelect );
        btnUpload=add_menu_layout.findViewById( R.id.btnUpload );



        //Event for button
        btnSelect.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseImage();                       //Let The user to get photo from the gallary and save the uri
            }
        } );


        btnUpload.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                uploadImage();
            }
        } );




        alertDialog.setView( add_menu_layout );
        alertDialog.setIcon( R.drawable.ic_shopping_cart_black_24dp);

        //set Button

        alertDialog.setPositiveButton( "yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialogInterface.dismiss();
                if (newFood != null)
                {
                    foodList.push().setValue( newFood );
                    Snackbar.make(rootLayout,"New Category"+newFood.getName()+"was added",Snackbar.LENGHT_SHORT).show();
                }
            }


        } );
        alertDialog.setPositiveButton( "No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialogInterface.dismiss();

            }
        } );
        alertDialog.show();


    }

    private void chooseImage() {
        Intent intent=new Intent();
        intent.setType( "image/*" );
        intent.setAction( Intent.ACTION_GET_CONTENT );
        startActivityForResult(Intent.createChooser( intent,"Select Picture" ), Common.PICK_IMAGE_REQUEST);

    }


    private void uploadImage() {
        if(saveUri != null)
        {
            final ProgressDialog mDialog= new ProgressDialog( this );
            mDialog.setMessage( "Uploading . . ." );
            mDialog.show();

            String imageName= UUID.randomUUID().toString();
            final StorageReference imageFolder = storageRefernce.child("images/"+imageName);

            imageFolder.putFile(saveUri).addOnSuccessListener((OnSuccessListener) (taskSnapshot)  {

                    mDialog.dismiss();
            Toast.makeText( Foodlist.this,"Uploaded !!! ",Toast.LENGTH_SHORT ).show();
            imageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                public void onSuccess(Uri uri) {

                    newFood=new Food();
                    newFood.setName(edtName.getText().toString());
                    newFood.setDescription(edtDescription.getText().toString());
                    newFood.setPrice(edtPrice.getText().toString());
                    newFood.setDiscount(edtDiscount.getText().toString());
                    newFood.setMenuID(categoryId);
                    newFood.setImage(uri.toString());

                }
            });

                });
            .addOnFailureListener( new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                mDialog.dismiss();
                Toast.makeText( Home.this ,""+e.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
            .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>(){
            public void OnProgress(UploadTask.TaskSnapshot taskSnapshot){
                double progress = (100.0*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                mDialog.setMessage( "Uploaded "+progress );
            }
        });

        }
    }


    private void loadListFood(String categoryId) {

        adapter=new FirebaseRecyclerAdapter<Food,FoodViewHolder>(
            Food.class,
            R.layout.food_item,
                FoodViewHolder.class,
                foodList.orderByChild( "menuId" ).equalTo( "categoryId" )

        ) {
            protected void populateViewHolder(FoodViewHolder viewHolder,Food model,int postion)
            {
                viewHolder.food_name.setText( model.getName() );
                Picasso.with(getBaseContext()).load(model.getImage()).info(viewHolder.food_image);

                viewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void OnClick(View view, int postion, boolean isLongClick) {

                    }
                });
            }

        };
        adapter.notifyDataSetChanged();
        recyclerView.setAdapter( adapter );
    }


    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode ==Common.PICK_IMAGE_REQUEST && resultCode ==RESULT_OK && data != null && data.getData()!= null)
        {
            saveUri=data.getData();
            btnSelect.setText("Image Selected !");
        }

    }


    public boolean onContextItemSelected(MenuItem item)
    {
        if (item.getTitle().equals( Common.UPDATE ))
        {
            showUpdateFoodDialog(adapter.getRef(item.getOrder()).getKey(),adapter.getItem(item.getOrder()));
        }
        else if (item.getTitle().equals( Common.DELETE))
        {

                    deleteFood(adapter.getRef(item.getOrder()).getKey());
        }
        return super.onContextItemSelected(item);
    }

    private void showUpdateFoodDialog(final String key, final Food item){

        AlertDialog.Builder alertDialog = new AlertDialog.Builder( Home.this);
        alertDialog.setTitle( "Edit Food" );
        alertDialog.setMessage( "Please Fill Full inforamtion" );

        LayoutInflater inflater=this.getLayoutInflater();
        View add_menu_layout=inflater.inflate( R.layout.add_new_mneu_layout,null );

        edtName=add_menu_layout.findViewById( R.id.edtName );
        edtDescription=add_menu_layout.findViewById( R.id.edtDescription );
        edtPrice=add_menu_layout.findViewById( R.id.edtPrice );
        edtDiscount=add_menu_layout.findViewById( R.id.edtDiscount );



        //set Defult Value for View
        edtName.setText(item.getName());
        edtDescription.setText(item.getDescription());
        edtDiscount.setText(item.getDiscount());
        edtPrice.setText(item.getPrice());


        btnSelect=add_menu_layout.findViewById( R.id.btnSelect );
        btnUpload=add_menu_layout.findViewById( R.id.btnUpload );



        //Event for button
        btnSelect.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseImage();                       //Let The user to get photo from the gallary and save the uri
            }
        } );


        btnUpload.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                changeImage(item);
            }
        } );

        alertDialog.setView( add_menu_layout );
        alertDialog.setIcon( R.drawable.ic_shopping_cart_black_24dp);

        //set Button

        alertDialog.setPositiveButton( "yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialogInterface.dismiss();


                    //Update Inforamtion

                    item.setName(edtName.getText().toStrig());
                    item.setDescription(edtDescription.getText().toStrig());
                    item.setDiscount(edtDiscount.getText().toStrig());
                    item.setPrice(edtPrice.getText().toStrig());



                    foodList.child(key).setValue( item );
                    Snackbar.make(rootLayout," Category"+item.getName()+"was Edited",Snackbar.LENGHT_SHORT).show();

            }


        } );
        alertDialog.setPositiveButton( "No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialogInterface.dismiss();

            }
        } );
        alertDialog.show();


    }


    private void changeImage(final Food item) {

        if(saveUri != null)
        {
            final ProgressDialog mDialog= new ProgressDialog( this );
            mDialog.setMessage( "Uploading . . ." );
            mDialog.show();

            String imageName= UUID.randomUUID().toString();
            final StorageReference imageFolder = storageRefernce.child("images/"+imageName);

            imageFolder.putFile(saveUri).addOnSuccessListener((OnSuccessListener) (taskSnapshot) {

                    mDialog.dismiss();
            Toast.makeText( Foodlist.this, "Uploaded !!! ", Toast.LENGTH_SHORT ).show();
            imageFolder.getDownloadUrl().addOnSuccessListener( new OnSuccessListener<Uri>() {
                public void onSuccess(Uri uri) {
                    public void onSuccess (Uri uri)
                    {
                        item.setImage( uri.toString() );

                    }
                }

            } );
            });
            .addOnFailureListener( new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                mDialog.dismiss();
                Toast.makeText( Foodlist.this, "" + e.getMessage(), Toast.LENGTH_SHORT ).show();
            }
        } );
            .addOnProgressListener( new OnProgressListener<UploadTask.TaskSnapshot>() {
            public void OnProgress(UploadTask.TaskSnapshot taskSnapshot) {
                double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                mDialog.setMessage( "Uploaded " + progress );
            }
        } );

        }
    }

    private void  deleteFood( String key)
    {
        foodList.child(key).removeValue();
    }


}
